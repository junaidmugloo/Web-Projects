<?php
require('../backends/connection-pdo.php');
session_start();
$msg_error='';
if(isset($_SESSION['msg']))
{
    $msg_error=$_SESSION['msg'];
    unset($_SESSION['msg']);
}
$id=$_GET['id'];
echo $id;
$quer="DELETE FROM `orders` WHERE `orders`.`id` ='$id'";
$query  = $pdoconn->prepare($quer);
if(!$query)
echo "Failde To Delete";
else
header('location:order-list.php');
?>