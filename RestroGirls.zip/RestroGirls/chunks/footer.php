<section class="ffooter">
		<footer class="page-footer">
          <div class="container">
            <div class="row">
              <div class="col l6 s12">
                <h5 class="white-text">Contact US</h5>
                <p class="grey-text text-lighten-4">Hawal Srinagar Jammu & Kashmir</p>
                <p class="grey-text text-lighten-4">Phone : +917006730307</p>
              </div>
              <div class="col l4 offset-l2 s12">
                <h5 class="white-text">Social Media Links</h5>
                <ul>
                  <li><a class="grey-text text-lighten-3" href="http://www.fb.com/junaidmugloo2">Facebook</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Instagram</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Twitter</a></li>
                  <li><a class="grey-text text-lighten-3" href="#!">Whatsapp</a></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2020 Copyright @ Kashtech
            <a class="grey-text text-lighten-4 right" href="http://kashtech.rf.gd">Made By Kashtech <span><i class="tiny material-icons">web</i></span></a>
            </div>
          </div>
        </footer>
	</section>